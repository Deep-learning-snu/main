# Segmentation Evalaution Test Data

## Source Images

*   [team_input.png](team_input.png) \
    Source:
    https://ai.googleblog.com/2018/03/semantic-image-segmentation-with.html
*   [cat_input.jpg](cat_input.jpg) \
    Source: https://www.flickr.com/photos/magdalena_b/4995858743
*   [bird_input.jpg](bird_input.jpg) \
    Source: https://www.flickr.com/photos/chivinskia/40619099560
